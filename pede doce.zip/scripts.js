document.addEventListener("DOMContentLoaded", function () {
    const addToCartButtons = document.querySelectorAll(".add-to-cart");
    const cartItemsList = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");
    const checkoutButton = document.getElementById("checkout-button");
    const checkoutTotalPrice = document.getElementById("checkout-total-price");
    const placeOrderButton = document.getElementById("place-order-button");
  
    const itemsInCart = [];
  
    const updateCartButtons = () => {
      addToCartButtons.forEach((button, index) => {
        button.addEventListener("click", () => {
          addToCart(index);
        });
      });
    };
  
    const addToCart = (index) => {
      itemsInCart.push(index);
      updateCartDisplay();
    };
  
    const removeFromCart = (index) => {
      const itemIndex = itemsInCart.indexOf(index);
      if (itemIndex !== -1) {
        itemsInCart.splice(itemIndex, 1);
        updateCartDisplay();
      }
    };
  
    const updateCartDisplay = () => {
      cartItemsList.innerHTML = "";
      let total = 0;
      itemsInCart.forEach((itemIndex) => {
        const brownie = document.querySelectorAll(".brownie")[itemIndex];
        const brownieTitle = brownie.querySelector("h2").textContent;
        const browniePrice = parseFloat(brownie.querySelector(".price").textContent.slice(1));
        total += browniePrice;
        const li = document.createElement("li");
        li.textContent = `${brownieTitle} - $${browniePrice.toFixed(2)}`;
        
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remover";
        removeButton.className = "remove-from-cart-item";
        removeButton.addEventListener("click", () => {
          removeFromCart(itemIndex);
        });
        
        li.appendChild(removeButton);
        cartItemsList.appendChild(li);
      });
      totalPrice.textContent = `Total: $${total.toFixed(2)}`;
      updateCheckoutButtonVisibility();
    };
  
    const updateCheckoutButtonVisibility = () => {
      checkoutButton.style.display = itemsInCart.length > 0 ? "inline-block" : "none";
      updateCheckoutTotalPrice();
    };
  
    const updateCheckoutTotalPrice = () => {
      const total = itemsInCart.reduce((acc, itemIndex) => {
        const brownie = document.querySelectorAll(".brownie")[itemIndex];
        const browniePrice = parseFloat(brownie.querySelector(".price").textContent.slice(1));
        return acc + browniePrice;
      }, 0);
      checkoutTotalPrice.textContent = `Total: $${total.toFixed(2)}`;
      placeOrderButton.style.display = total > 0 ? "inline-block" : "none";
    };
  
    updateCartButtons();
  });
  