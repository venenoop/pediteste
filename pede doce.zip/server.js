const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database'); // Importe o arquivo database.js que você criou

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Rota para buscar os pedidos aprovados
app.get('/api/pedidos', (req, res) => {
    db.all('SELECT * FROM pedidos WHERE status = 1', (err, rows) => {
        if (err) {
            console.error('Erro ao buscar pedidos:', err.message);
            res.status(500).json({ error: 'Erro ao buscar pedidos' });
        } else {
            res.json(rows);
        }
    });
});

// Rota para aprovar um pedido
app.post('/api/aprovar/:codigoPedido', (req, res) => {
    const codigoPedido = req.params.codigoPedido;
    const novoStatus = req.body.status;

    db.run('UPDATE pedidos SET status = ? WHERE codigo = ?', [novoStatus, codigoPedido], (err) => {
        if (err) {
            console.error('Erro ao aprovar pedido:', err.message);
            res.status(500).json({ error: 'Erro ao aprovar pedido' });
        } else {
            res.json({ message: 'Pedido aprovado com sucesso' });
        }
    });
});

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});
